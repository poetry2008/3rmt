<?php
/*
  $Id: 838507665fa85ba563f4ecf005a494cafd398aff $
*/
require_once 'includes/application_top.php';
require_once DIR_WS_ACTIONS.'checkout_payment.php';
require_once "checkout_payment_template.php";
