<?php
/*
  $Id: fef7c3a1a12b0841be31eeb1c2822aeab35260fb $
*/
require('includes/application_top.php');
require(DIR_WS_ACTIONS.'checkout_payment.php');
require_once "checkout_payment_template.php";
