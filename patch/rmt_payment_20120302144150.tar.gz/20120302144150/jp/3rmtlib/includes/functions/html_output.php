<?php
/*
  $Id: e78d292527dbe574b790e941ce90e489a70c419e $
*/


////
// Ultimate SEO URLs v2.1
// The HTML href link wrapper function
  function tep_href_link($page = '', $parameters = '', $connection = 'NONSSL', $add_session_id = true, $search_engine_safe = true) {
    global $seo_urls;
    return $seo_urls->href_link($page, $parameters, $connection, $add_session_id);
  }

////
// The HTML image wrapper function
  function tep_image($src, $alt = '', $width = '', $height = '', $parameters = '') {
    if ( (empty($src) || ($src == DIR_WS_IMAGES)) && (IMAGE_REQUIRED == 'false') ) {
      return false;
    }
##########
   if(!file_exists(DIR_FS_CATALOG . '/' . $src)
       && file_exists(DIR_FS_CATALOG . '/' . str_replace('images/', 'default_images/', $src))
       ){
     $src = str_replace('images/', 'default_images/', $src);
     }
##########
   if ($image_size = @getimagesize($src)) {
      if ((CONFIG_CALCULATE_IMAGE_SIZE == 'true' && $src != DIR_WS_IMAGES . 'pixel_black.gif' && $src != DIR_WS_IMAGES . 'pixel_trans.gif' && $src != DIR_WS_IMAGES . 'pixel_silver.gif' )) {
    if ( ($width) || ($height) ) {
      if ( $width=="100%" ) {
        $width = $image_size[0];
      } elseif ( $height=="100%" ) {
        $height = $image_size[1];
      } elseif ( $width==0 ) {
        unset($width);
      } elseif ( $height==0 ) {
        unset($height);
      }
      //print(DIR_FS_CATALOG . '/' .$src. $width. $height. DIR_FS_CATALOG . '/' . DIR_WS_IMAGES . 'imagecache');
      $src = thumbimage(DIR_FS_CATALOG . '/' .$src, $width, $height, 1, 1, DIR_FS_CATALOG . '/' . DIR_WS_IMAGES . 'imagecache');
      if ((($image_size[1]/$height) > ($image_size[0]/$width) ) && $height>0){
         $width=ceil(($image_size[0]/$image_size[1])* $height);
      } elseif ($width>0) {
         $height=ceil($width/($image_size[0]/$image_size[1]));
      }
    }
    }
      } elseif (IMAGE_REQUIRED == 'false') {
        return '';
      } 
  

// alt is added to the img tag even if it is null to prevent browsers from outputting
// the image filename as default
    $image = '<img src="' . tep_output_string($src) . '" alt="' . tep_output_string($alt) . '"';

    /*if (tep_not_null($alt)) {
      $image .= ' title=" ' . tep_output_string($alt) . ' "';
    }*/


    if (tep_not_null($width) && tep_not_null($height)) {
      $image .= ' width="' . tep_output_string($width) . '" height="' . tep_output_string($height) . '"';
    }

    if (tep_not_null($parameters)) $image .= ' ' . $parameters;

    $image .= '>';

    return $image;
  }

// The HTML image wrapper function
  function tep_image2($src, $alt = '', $width = '', $height = '', $parameters = '') {
    if ( (empty($src) || ($src == DIR_WS_IMAGES)) && (IMAGE_REQUIRED == 'false') ) {
      return false;
    }
##########
   if(!file_exists(DIR_FS_CATALOG . '/' . $src)
       && file_exists(DIR_FS_CATALOG . '/' . str_replace('images/', 'default_images/', $src))
       ){
     $src = str_replace('images/', 'default_images/', $src);
     }
##########
   if ($image_size = @getimagesize($src)) {
      if ((CONFIG_CALCULATE_IMAGE_SIZE == 'true' && $src != DIR_WS_IMAGES . 'pixel_black.gif' && $src != DIR_WS_IMAGES . 'pixel_trans.gif' && $src != DIR_WS_IMAGES . 'pixel_silver.gif' )) {
    if ( ($width) || ($height) ) {
      if ( $width=="100%" ) {
        $width = $image_size[0];
      } elseif ( $height=="100%" ) {
        $height = $image_size[1];
      } elseif ( $width==0 ) {
        unset($width);
      } elseif ( $height==0 ) {
        unset($height);
      }
      $src=thumbimage2(DIR_FS_CATALOG . '/' .$src, $width, $height, 1, 1, DIR_FS_CATALOG . '/' . DIR_WS_IMAGES . 'imagecache2');
      if ((($image_size[1]/$height) > ($image_size[0]/$width) ) && $height>0){
         $width=ceil(($image_size[0]/$image_size[1])* $height);
      } elseif ($width>0) {
         $height=ceil($width/($image_size[0]/$image_size[1]));
      }
    }
    }
      } elseif (IMAGE_REQUIRED == 'false') {
        return '';
      } 
  

// alt is added to the img tag even if it is null to prevent browsers from outputting
// the image filename as default
    $image = '<img src="' . tep_output_string($src) . '" alt="' . tep_output_string($alt) . '"';

    /*if (tep_not_null($alt)) {
      $image .= ' title=" ' . tep_output_string($alt) . ' "';
    }*/


    if (tep_not_null($width) && tep_not_null($height)) {
      $image .= ' width="' . tep_output_string($width) . '" height="' . tep_output_string($height) . '"';
    }

    if (tep_not_null($parameters)) $image .= ' ' . $parameters;

    $image .= '>';

    return $image;
  }



  function tep_image3($src, $alt = '', $width = '', $height = '', $parameters = '') {
    //echo 'tep_image3';
    if ( (empty($src) || ($src == DIR_WS_IMAGES)) && (IMAGE_REQUIRED == 'false') ) {
      return false;
    }
##########
   if(!file_exists(DIR_FS_CATALOG . '/' . $src)
       && file_exists(DIR_FS_CATALOG . '/' . str_replace('images/', 'default_images/', $src))
       ){
     $src = str_replace('images/', 'default_images/', $src);
     }
##########
   if ($image_size = @getimagesize($src)) {
      if ((CONFIG_CALCULATE_IMAGE_SIZE == 'true' && $src != DIR_WS_IMAGES . 'pixel_black.gif' && $src != DIR_WS_IMAGES . 'pixel_trans.gif' && $src != DIR_WS_IMAGES . 'pixel_silver.gif' )) {
    if ( ($width) || ($height) ) {
      if ( $width=="100%" ) {
        $width = $image_size[0];
      } elseif ( $height=="100%" ) {
        $height = $image_size[1];
      } elseif ( $width==0 ) {
        unset($width);
      } elseif ( $height==0 ) {
        unset($height);
      }
      $src=thumbimage3(DIR_FS_CATALOG . '/' .$src, $width, $height, 1, 1, DIR_FS_CATALOG . '/' . DIR_WS_IMAGES . 'imagecache3');
      if ((($image_size[1]/$height) > ($image_size[0]/$width) ) && $height>0){
         $width=ceil(($image_size[0]/$image_size[1])* $height);
      } elseif ($width>0) {
         $height=ceil($width/($image_size[0]/$image_size[1]));
      }
    }
    }
      } elseif (IMAGE_REQUIRED == 'false') {
        return '';
      } 
  

// alt is added to the img tag even if it is null to prevent browsers from outputting
// the image filename as default
    $image = '<img src="' . tep_output_string($src) . '" border="0" alt="' . tep_output_string($alt) . '"';

    /*if (tep_not_null($alt)) {
      $image .= ' title=" ' . tep_output_string($alt) . ' "';
    }*/


    if (tep_not_null($width) && tep_not_null($height)) {
      $image .= ' width="' . tep_output_string($width) . '" height="' . tep_output_string($height) . '"';
    }

    if (tep_not_null($parameters)) $image .= ' ' . $parameters;

    $image .= '>';

    return $image;
  }

////
// The HTML form submit button wrapper function
// Outputs a button in the selected language
  function tep_image_submit($image, $alt = '', $parameters = '') {
    global $language;

    $image_submit = '<input type="image" src="' . tep_parse_input_field_data(DIR_WS_LANGUAGES . $language . '/images/buttons/' . $image, array('"' => '&quot;')) . '" alt="' . tep_parse_input_field_data($alt, array('"' => '&quot;')) . '"';

    //if (tep_not_null($alt)) $image_submit .= ' title=" ' . tep_parse_input_field_data($alt, array('"' => '&quot;')) . ' "';

    if (tep_not_null($parameters)) $image_submit .= ' ' . $parameters;

    $image_submit .= '>';

    return $image_submit;
  }

////
// Output a function button in the selected language
  function tep_image_button($image, $alt = '', $parameters = '') {
    global $language;

    return tep_image(DIR_WS_LANGUAGES . $language . '/images/buttons/' . $image, $alt, '', '', $parameters);
  }

////
// Output a separator either through whitespace, or with an image
  function tep_draw_separator($image = 'pixel_black.gif', $width = '100%', $height = '1') {
    return tep_image(DIR_WS_IMAGES . $image, '', $width, $height);
  }

////
// Output a form
  function tep_draw_form($name, $action, $method = 'post', $parameters = '') {
    $form = '<form name="' . tep_parse_input_field_data($name, array('"' => '&quot;')) . '" action="' . tep_parse_input_field_data($action, array('"' => '&quot;')) . '" method="' . tep_parse_input_field_data($method, array('"' => '&quot;')) . '"';

    if (tep_not_null($parameters)) $form .= ' ' . $parameters;

    $form .= '>';

    return $form;
  }

////
// Output a form input field
  function tep_draw_input_field($name, $value = '', $parameters = '', $type = 'text', $reinsert_value = true) {
    $field = '<input type="' . tep_parse_input_field_data($type, array('"' => '&quot;')) . '" name="' . tep_parse_input_field_data($name, array('"' => '&quot;')) . '"';

    if ( (isset($GLOBALS[$name])) && ($reinsert_value == true) ) {
      $field .= ' value="' . tep_parse_input_field_data($GLOBALS[$name], array('"' => '&quot;')) . '"';
    } elseif (tep_not_null($value)) {
      $field .= ' value="' . tep_parse_input_field_data($value, array('"' => '&quot;')) . '"';
    } else {
      $field .= ' value=""';
    }

    if (tep_not_null($parameters)) $field .= ' ' . $parameters;

    $field .= '>';

    return $field;
  }

////
// Output a form password field
  function tep_draw_password_field($name, $value = '', $parameters = 'maxlength="40"') {
    return tep_draw_input_field($name, $value, $parameters, 'password', false);
  }

////
// Output a selection field - alias function for tep_draw_checkbox_field() and tep_draw_radio_field()
  function tep_draw_selection_field($name, $type, $value = '', $checked = false, $parameters = '') {
    $selection = '<input type="' . tep_parse_input_field_data($type, array('"' => '&quot;')) . '" name="' . tep_parse_input_field_data($name, array('"' => '&quot;')) . '"';

    if (tep_not_null($value)) $selection .= ' value="' . tep_parse_input_field_data($value, array('"' => '&quot;')) . '"';

    if (!isset($GLOBALS[$name])) $GLOBALS[$name] = NULL;
    if ( ($checked == true) || ($GLOBALS[$name] == 'on') || ( (isset($value)) && ($GLOBALS[$name] == $value) ) ) {
      $selection .= ' CHECKED';
    }

    if (tep_not_null($parameters)) $selection .= ' ' . $parameters;

    $selection .= '>';

    return $selection;
  }

////
// Output a form checkbox field
  function tep_draw_checkbox_field($name, $value = '', $checked = false, $parameters = '') {
    return tep_draw_selection_field($name, 'checkbox', $value, $checked, $parameters);
  }

////
// Output a form radio field
  function tep_draw_radio_field($name, $value = '', $checked = false, $parameters = '') {
    return tep_draw_selection_field($name, 'radio', $value, $checked, $parameters);
  }

////
// Output a form textarea field
  function tep_draw_textarea_field($name, $wrap, $width, $height, $text = '', $parameters = '', $reinsert_value = true) {
    $field = '<textarea name="' . tep_parse_input_field_data($name, array('"' => '&quot;')) . '" wrap="' . tep_parse_input_field_data($wrap, array('"' => '&quot;')) . '" cols="' . tep_parse_input_field_data($width, array('"' => '&quot;')) . '" rows="' . tep_parse_input_field_data($height, array('"' => '&quot;')) . '"';

    if (tep_not_null($parameters)) $field .= ' ' . $parameters;

    $field .= '>';

    if ( (isset($GLOBALS[$name])) && ($reinsert_value == true) ) {
      $field .= stripslashes($GLOBALS[$name]);
    } elseif (tep_not_null($text)) {
      $field .= $text;
    }

    $field .= '</textarea>';

    return $field;
  }

////
// Output a form hidden field
  function tep_draw_hidden_field($name, $value = '', $parameters = '') {
    $field = '<input type="hidden" name="' . tep_output_string($name) . '"';

    if (tep_not_null($value)) {
      $field .= ' value="' . tep_output_string($value) . '"';
    } elseif (isset($GLOBALS[$name])) {
      $field .= ' value="' . tep_output_string(stripslashes($GLOBALS[$name])) . '"';
    }

    if (tep_not_null($parameters)) $field .= ' ' . $parameters;

    $field .= '>';

    return $field;
  }

////
// Hide form elements
  function tep_hide_session_id() {
    if (defined('SID') && tep_not_null(SID)) return tep_draw_hidden_field(tep_session_name(), tep_session_id());
  }

////
// Output a form pull down menu
  function tep_draw_pull_down_menu($name, $values, $default = '', $parameters = '', $required = false) {
    $field = '<select id="' . $name . '" name="' . tep_parse_input_field_data($name, array('"' => '&quot;')) . '"';

    if (tep_not_null($parameters)) $field .= ' ' . $parameters;

    $field .= '>';

    if (empty($default) && isset($GLOBALS[$name])) $default = $GLOBALS[$name];

    for ($i=0, $n=sizeof($values); $i<$n; $i++) {
      $field .= '<option value="' . tep_parse_input_field_data($values[$i]['id'], array('"' => '&quot;')) . '"';
      if ($default == $values[$i]['id']) {
        $field .= ' SELECTED';
      }

      $field .= '>' . tep_parse_input_field_data($values[$i]['text'], array('"' => '&quot;', '\'' => '&#039;', '<' => '&lt;', '>' => '&gt;')) . '</option>';
    }
    $field .= '</select>';

    if ($required == true) $field .= TEXT_FIELD_REQUIRED;

    return $field;
  }

////
// Creates a pull-down list of countries
  function tep_get_country_list($name, $selected = '', $parameters = '') {
    $countries_array = array(array('id' => '', 'text' => PULL_DOWN_DEFAULT));
    $countries = tep_get_countries();

    for ($i=0, $n=sizeof($countries); $i<$n; $i++) {
      $countries_array[] = array('id' => $countries[$i]['countries_id'], 'text' => $countries[$i]['countries_name']);
    }

    return tep_draw_pull_down_menu($name, $countries_array, $selected, $parameters);
  }

////
// Creates a pull-down list of states
// added for Japanese localize
  function tep_get_zone_list($name, $country_code = '', $selected = '', $parameters = '') {
    $zones_array = array();
//ccdd
    $zones_query = tep_db_query("
        select zone_name 
        from " . TABLE_ZONES . " 
        where zone_country_id = '" . tep_db_input($country_code) . "' 
        order by " . (($country_code == 107) ? "zone_code" : "zone_name")
    );
    while ($zones_values = tep_db_fetch_array($zones_query)) {
      $zones_array[] = array('id' => $zones_values['zone_name'], 'text' => $zones_values['zone_name']);
    }
    return tep_draw_pull_down_menu($name, $zones_array, $selected, $parameters);
  }
  function thumbimage ($image, $x, $y, $aspectratio, $resize, $cachedir){
     $types = array (1 => "gif", "jpeg", "png", "swf", "psd", "wbmp");
     $not_supported_formats = array ("GIF"); 
     umask(0);
     !is_dir ($cachedir)
         ? mkdir ($cachedir, 0777)
         : @chmod($cachedir, 0777);

       (!isset ($x) || ereg ('^[0-9]{1,}$', $x, $regs)) &&
       (!isset ($y) || ereg ('^[0-9]{1,}$', $y, $regs)) &&
       (isset ($x) || isset ($y))
            ? true
          : DIE ('Image width or height undefine!');

     !isset ($resize) || !ereg ('^[0|1]$', $resize, $regs)
          ? $resize = 0
          : $resize;

     !isset ($aspectratio) || !ereg ('^[0|1]$', $aspectratio, $regs)
          ? isset ($x) && isset ($y)
                 ? $aspectratio = 1
                 : $aspectratio = 0
          : $aspectratio;

     !isset ($image)
          ? DIE ('Image undefine.')
          : !file_exists($image)
               ? DIE ('Image not exists!')
               : false;

     $imagedata = getimagesize($image);

     !$imagedata[2] || $imagedata[2] == 4 || $imagedata[2] == 5
          ? DIE ('Image type not avaliable!')
          : false;

     $imgtype = "!(ImageTypes() & IMG_" . strtoupper($types[$imagedata[2]]) . ");";
     if ((eval($imgtype)) || (in_array(strtoupper(array_pop(explode('.', basename($image)))),$not_supported_formats))) {
        $image = substr ($image, (strrpos (DIR_FS_CATALOG . '/', '/'))+1);
        return $image;
     }

     if (!isset ($x)) $x = floor ($y * $imagedata[0] / $imagedata[1]);


     if (!isset ($y)) $y = floor ($x * $imagedata[1] / $imagedata[0]);

     if ($aspectratio && isset ($x) && isset ($y)) {
    if ((($imagedata[1]/$y) > ($imagedata[0]/$x) )){
       $x=ceil(($imagedata[0]/$imagedata[1])* $y);
    } else {
       $y=ceil($x/($imagedata[0]/$imagedata[1]));
    }
     }

     $thumbfile =  '/' . basename($image);
     if (file_exists ($cachedir.$thumbfile)) {
          $thumbdata = getimagesize ($cachedir.$thumbfile);
          $thumbdata[0] == $x && $thumbdata[1] == $y
               ? $iscached = true
               : $iscached = false;
     } else {
          $iscached = false;
     }

     if (!$iscached) {
          ($imagedata[0] > $x || $imagedata[1] > $y) || (($imagedata[0] < $x || $imagedata[1] < $y) && $resize)
               ? $makethumb = true
               : $makethumb = false;
     } else {
          $makethumb = false;
     }

     if ($makethumb) {
          $image = call_user_func("imagecreatefrom".$types[$imagedata[2]], $image);
        if (function_exists("imagecreatetruecolor") && ($thumb = imagecreatetruecolor ($x, $y))) {
        imagecopyresampled ($thumb, $image, 0, 0, 0, 0, $x, $y, $imagedata[0], $imagedata[1]);
      } else {
        $thumb = imagecreate ($x, $y);
        imagecopyresized ($thumb, $image, 0, 0, 0, 0, $x, $y, $imagedata[0], $imagedata[1]);
      }
          call_user_func("image".$types[$imagedata[2]], $thumb, $cachedir.$thumbfile);
          imagedestroy ($image);
          imagedestroy ($thumb);
          $image = DIR_WS_IMAGES . 'imagecache' . $thumbfile;
     } else {
          $iscached
               ? $image = DIR_WS_IMAGES . 'imagecache' . $thumbfile
               : $image = substr ($image, (strrpos (DIR_FS_CATALOG . '/', '/'))+1);
     }
  return $image;

}



//images2

  function thumbimage2 ($image, $x, $y, $aspectratio, $resize, $cachedir){


     $types = array (1 => "gif", "jpeg", "png", "swf", "psd", "wbmp");
   $not_supported_formats = array ("GIF"); 
     umask(0);
     !is_dir ($cachedir)
         ? mkdir ($cachedir, 0777)
         : @chmod($cachedir, 0777);

       (!isset ($x) || ereg ('^[0-9]{1,}$', $x, $regs)) &&
       (!isset ($y) || ereg ('^[0-9]{1,}$', $y, $regs)) &&
       (isset ($x) || isset ($y))
            ? true
          : DIE ('Fehlende(r) oder ung繝ｻtige(r) Gr繝ｻenparameter!');

     !isset ($resize) || !ereg ('^[0|1]$', $resize, $regs)
          ? $resize = 0
          : $resize;

     !isset ($aspectratio) || !ereg ('^[0|1]$', $aspectratio, $regs)
          ? isset ($x) && isset ($y)
                 ? $aspectratio = 1
                 : $aspectratio = 0
          : $aspectratio;

     !isset ($image)
          ? DIE ('Es wurde kein Bild angegeben!')
          : !file_exists($image)
               ? DIE ('Die angegebene Datei konnte nicht auf dem Server gefunden werden!')
               : false;

     $imagedata = getimagesize($image);

     !$imagedata[2] || $imagedata[2] == 4 || $imagedata[2] == 5
          ? DIE ('Bei der angegebenen Datei handelt es sich nicht um ein Bild!')
          : false;

   $imgtype="!(ImageTypes() & IMG_" . strtoupper($types[$imagedata[2]]) . ");";
     if ((eval($imgtype)) || (in_array(strtoupper(array_pop(explode('.', basename($image)))),$not_supported_formats))) {
      $image = substr ($image, (strrpos (DIR_FS_CATALOG . '/', '/'))+1);
    return $image;

     }

     if (!isset ($x)) $x = floor ($y * $imagedata[0] / $imagedata[1]);


     if (!isset ($y)) $y = floor ($x * $imagedata[1] / $imagedata[0]);

     if ($aspectratio && isset ($x) && isset ($y)) {
    if ((($imagedata[1]/$y) > ($imagedata[0]/$x) )){
       $x=ceil(($imagedata[0]/$imagedata[1])* $y);
    } else {
       $y=ceil($x/($imagedata[0]/$imagedata[1]));
    }
     }

     $thumbfile =  '/' . basename($image);
     if (file_exists ($cachedir.$thumbfile)) {
          $thumbdata = getimagesize ($cachedir.$thumbfile);
          $thumbdata[0] == $x && $thumbdata[1] == $y
               ? $iscached = true
               : $iscached = false;
     } else {
          $iscached = false;
     }

     if (!$iscached) {
          ($imagedata[0] > $x || $imagedata[1] > $y) || (($imagedata[0] < $x || $imagedata[1] < $y) && $resize)
               ? $makethumb = true
               : $makethumb = false;
     } else {
          $makethumb = false;
     }



     if ($makethumb) {
          $image = call_user_func("imagecreatefrom".$types[$imagedata[2]], $image);
    if (function_exists("imagecreatetruecolor") && ($thumb = imagecreatetruecolor ($x, $y))) {
    imagecopyresampled ($thumb, $image, 0, 0, 0, 0, $x, $y, $imagedata[0], $imagedata[1]);
    } else {
    $thumb = imagecreate ($x, $y);
    imagecopyresized ($thumb, $image, 0, 0, 0, 0, $x, $y, $imagedata[0], $imagedata[1]);
    }
          call_user_func("image".$types[$imagedata[2]], $thumb, $cachedir.$thumbfile);
          imagedestroy ($image);
          imagedestroy ($thumb);
          $image = DIR_WS_IMAGES . 'imagecache2' . $thumbfile;
     } else {
          $iscached
               ? $image = DIR_WS_IMAGES . 'imagecache2' . $thumbfile
               : $image = substr ($image, (strrpos (DIR_FS_CATALOG . '/', '/'))+1);
     }
return $image;

}


//images3

  function thumbimage3 ($image, $x, $y, $aspectratio, $resize, $cachedir){


     $types = array (1 => "gif", "jpeg", "png", "swf", "psd", "wbmp");
   $not_supported_formats = array ("GIF"); 
     umask(0);
     !is_dir ($cachedir)
         ? mkdir ($cachedir, 0777)
         : @chmod($cachedir, 0777);

       (!isset ($x) || ereg ('^[0-9]{1,}$', $x, $regs)) &&
       (!isset ($y) || ereg ('^[0-9]{1,}$', $y, $regs)) &&
       (isset ($x) || isset ($y))
            ? true
          : DIE ('Fehlende(r) oder ung繝ｻtige(r) Gr繝ｻenparameter!');

     !isset ($resize) || !ereg ('^[0|1]$', $resize, $regs)
          ? $resize = 0
          : $resize;

     !isset ($aspectratio) || !ereg ('^[0|1]$', $aspectratio, $regs)
          ? isset ($x) && isset ($y)
                 ? $aspectratio = 1
                 : $aspectratio = 0
          : $aspectratio;

     !isset ($image)
          ? DIE ('Es wurde kein Bild angegeben!')
          : !file_exists($image)
               ? DIE ('Die angegebene Datei konnte nicht auf dem Server gefunden werden!')
               : false;

     $imagedata = getimagesize($image);

     !$imagedata[2] || $imagedata[2] == 4 || $imagedata[2] == 5
          ? DIE ('Bei der angegebenen Datei handelt es sich nicht um ein Bild!')
          : false;

   $imgtype="!(ImageTypes() & IMG_" . strtoupper($types[$imagedata[2]]) . ");";
   //echo $imgtype;
     if ((eval($imgtype)) || (in_array(strtoupper(array_pop(explode('.', basename($image)))),$not_supported_formats))) {
        $image = substr ($image, (strrpos (DIR_FS_CATALOG . '/', '/'))+1);
      return $image;

     }

     if (!isset ($x)) $x = floor ($y * $imagedata[0] / $imagedata[1]);


     if (!isset ($y)) $y = floor ($x * $imagedata[1] / $imagedata[0]);

     if ($aspectratio && isset ($x) && isset ($y)) {
    if ((($imagedata[1]/$y) > ($imagedata[0]/$x) )){
       $x=ceil(($imagedata[0]/$imagedata[1])* $y);
    } else {
       $y=ceil($x/($imagedata[0]/$imagedata[1]));
    }
     }

     $thumbfile =  '/' . basename($image);
     if (file_exists ($cachedir.$thumbfile)) {
          $thumbdata = getimagesize ($cachedir.$thumbfile);
          $thumbdata[0] == $x && $thumbdata[1] == $y
               ? $iscached = true
               : $iscached = false;
     } else {
          $iscached = false;
     }

     if (!$iscached) {
          ($imagedata[0] > $x || $imagedata[1] > $y) || (($imagedata[0] < $x || $imagedata[1] < $y) && $resize)
               ? $makethumb = true
               : $makethumb = false;
     } else {
          $makethumb = false;
     }



     if ($makethumb) {
          $image = call_user_func("imagecreatefrom".$types[$imagedata[2]], $image);
    if (function_exists("imagecreatetruecolor") && ($thumb = imagecreatetruecolor ($x, $y))) {
    imagecopyresampled ($thumb, $image, 0, 0, 0, 0, $x, $y, $imagedata[0], $imagedata[1]);
    } else {
    $thumb = imagecreate ($x, $y);
    imagecopyresized ($thumb, $image, 0, 0, 0, 0, $x, $y, $imagedata[0], $imagedata[1]);
    }
          call_user_func("image".$types[$imagedata[2]], $thumb, $cachedir.$thumbfile);
          imagedestroy ($image);
          imagedestroy ($thumb);
          $image = DIR_WS_IMAGES . 'imagecache3' . $thumbfile;
     } else {
          $iscached
               ? $image = DIR_WS_IMAGES . 'imagecache3' . $thumbfile
               : $image = substr ($image, (strrpos (DIR_FS_CATALOG . '/', '/'))+1);
     }
return $image;

}

function info_tep_href_link($romaji)
{
  global $request_type;
  $returnstr = HTTP_SERVER . DIR_WS_CATALOG;
    // 为了适应不同域名的ssl
    if ($_SERVER['HTTP_HOST'] == substr(HTTPS_SERVER, 8)) {
      $returnstr .= "info/".urlencode($romaji).".html";
    } else {
      // id 要求登陆之前不传sid
      if (defined('SITE_ID') && (SITE_ID == 4 || SITE_ID == 5 || SITE_ID == 6 || SITE_ID == 7 || SITE_ID == 8 || SITE_ID == 9)) {
        if (($request_type == 'NONSSL' && $connection == 'SSL') || ($request_type == 'SSL' && tep_session_is_registered('customer_id'))) {
          $returnstr .= "info/".urlencode($romaji).".html?".tep_session_name()."=".tep_session_id();
        } else {
          $returnstr .= "info/".urlencode($romaji).".html";
        }
      } else {
        //$returnstr .= "info/".urlencode($romaji).".html";
        if ($request_type == 'SSL' && $connection == 'SSL') {
          // 不同域名间ssl间跳转不加sid
          $returnstr .= "info/".urlencode($romaji).".html";
        } else if ($request_type == 'NONSSL' && $connection == 'NONSSL') {
          $returnstr .= "info/".urlencode($romaji).".html";
        } else {
          // 不同域名间ssl和非ssl互相跳转增加sid
          $returnstr .= "info/".urlencode($romaji).".html?".tep_session_name()."=".tep_session_id();
        }
      }
    }
  return $returnstr;
}

function tags_tep_href_link($tags_id)
{
  //$returnstr = HTTP_SERVER . DIR_WS_CATALOG;
  $returnstr = DIR_WS_CATALOG;
  
  $returnstr .= "tags/t-".$tags_id.".html";
  return $returnstr;
}


/*
  支付方法的限定额度，如果不满足则不能选择支付方法
*/
function toNumber($var){
  //  echo $var;
  if( is_numeric( $var ) )
    {
      if( (float)$var != (int)$var )
        {
          return (float)$var;
        }
      else
        {
          return (int)$var;
        }
    }
    if( $var == "true" )    return true;
    if( $var == "false" )    return false;
    return $var;
}

function tep_tags_link()
{
  global $request_type;
  $returnstr = HTTP_SERVER . DIR_WS_CATALOG;
  if ($request_type == 'SSL') {
    $returnstr .= "tags/?".tep_session_name()."=".tep_session_id();
  } else {
    $returnstr .= "tags/"; 
  }
  return $returnstr;
}

function tep_preorder_href_link($pid, $romaji, $param = null)
{
  global $request_type;
  $returnstr = HTTP_SERVER . DIR_WS_CATALOG;
  $param_str = '';  
  if ($param) {
    $param_str = '?'.$param; 
  }
  
  $categories = tep_get_categories_by_pid($pid);
  $categoriesToString = '';
  if (count($categories)) {
    foreach ($categories as $k => $v) {
      $categories[$k] = urlencode($v); 
    }
    $categoriesToString = @join('/', $categories).'/'; 
  }
  
  if ($_SERVER['HTTP_HOST'] == substr(HTTPS_SERVER, 8)) {
      $returnstr .= 'preorder/'.$categoriesToString.urlencode($romaji).'.html'.$param_str;
    } else {
        if ($request_type == 'SSL') {
          $returnstr .= "preorder/".$categoriesToString.urlencode($romaji).".html".$param_str.'&'.tep_session_name()."=".tep_session_id();
        } else {
          $returnstr .= "preorder/".$categoriesToString.urlencode($romaji).".html".$param_str;
        }
    }
  return $returnstr;
}


