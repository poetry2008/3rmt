<?php
require_once DIR_WS_LANGUAGES . $language . '/' . FILENAME_CHECKOUT_PAYMENT;
// if the customer is not logged on, redirect them to the login page
if (!tep_session_is_registered('customer_id')) {
  $navigation->set_snapshot();
  tep_redirect(tep_href_link(FILENAME_LOGIN, '', 'SSL'));
}

// if there is nothing in the customers cart, redirect them to the shopping cart page
if ($cart->count_contents() < 1) {
  tep_redirect(tep_href_link(FILENAME_SHOPPING_CART, '', 'SSL'));
}

// avoid hack attempts during the checkout procedure by checking the internal cartID
if (isset($cart->cartID) && tep_session_is_registered('cartID')) {
  if ($cart->cartID != $cartID) {
    tep_redirect(tep_href_link(FILENAME_CHECKOUT_SHIPPING, '', 'SSL'));
  }
}

// Stock Check
if ( (STOCK_CHECK == 'true') && (STOCK_ALLOW_CHECKOUT != 'true') ) {
  $products = $cart->get_products();
  for ($i=0, $n=sizeof($products); $i<$n; $i++) {
    if (tep_check_stock($products[$i]['id'], $products[$i]['quantity'])) {
      tep_redirect(tep_href_link(FILENAME_SHOPPING_CART, '', 'SSL'));
      break;
    }
  }
}

// if no billing destination address was selected, use the customers own address as default
if (!tep_session_is_registered('billto')) {
  tep_session_register('billto');
  $billto = $customer_default_address_id;
} else {
  // verify the selected billing address
  //ccdd
  $check_address_query = tep_db_query("select count(*) as total from " . TABLE_ADDRESS_BOOK . " where customers_id = '" . (int)$customer_id . "' and address_book_id = '" . (int)$billto . "'");
  $check_address = tep_db_fetch_array($check_address_query);

  if ($check_address['total'] != '1') {
    $billto = $customer_default_address_id;
    if (tep_session_is_registered('payment')) tep_session_unregister('payment');
  }
}

require_once DIR_WS_CLASSES . 'order.php';
$order = new order;

if (!tep_session_is_registered('comments')) tep_session_register('comments');

$total_weight = $cart->show_weight();
$total_count = $cart->count_contents();

$breadcrumb->add(NAVBAR_TITLE_1, tep_href_link(FILENAME_SHOPPING_CART, '', 'SSL'));
$breadcrumb->add(NAVBAR_TITLE_2, tep_href_link(FILENAME_CHECKOUT_PAYMENT, '', 'SSL'));
// load all enabled payment modules



if(MODULE_ORDER_TOTAL_POINT_STATUS == 'true') {
  //ccdd
  $point_query = tep_db_query("select point from " . TABLE_CUSTOMERS . " where customers_id = '" . $customer_id . "'");
  $point = tep_db_fetch_array($point_query);
}
require_once DIR_WS_CLASSES . 'payment.php';



//准备变量

$payment_modules =  payment::getInstance(SITE_ID);
$selection = $payment_modules->selection();



//统一的头输出 

page_head();?>
<script type="text/javascript" src="./js/jquery-1.3.2.min.js">
  </script>
  <script type="text/javascript" src="./js/payment.js">
  </script>
  <?php
  //输出payment 的javascript验证
  if(MODULE_ORDER_TOTAL_POINT_STATUS == 'true') 
    {
      echo $payment_modules->javascript_validation($point['point']); 
    }
?>
</head>
