<?php
/*
   $Id: 4d29385e69a5935e418e309a78f191ca7eb00163 $
 */

// 代金引換払い(手数料が購入金額に連動)
require_once (DIR_WS_CLASSES . 'basePayment.php');
class rakuten_bank  extends basePayment  implements paymentInterface {
  var $site_id, $code, $title, $description, $enabled, $n_fee, $s_error, $email_footer,$c_prefix, $show_payment_info;
  var $arrs2d = array('１' => '1', '２' => '2', '３' => '3', '４' => '4', 
       '５' => '5', '６' => '6', '７' => '7', '８' => '8', '９' => '9', '０' => '0','－' => '-');

  function loadSpecialSettings($site_id=0){
    $this->site_id = $site_id;
    $this->code               = 'rakuten_bank';
    $this->field_description  = 'TS_MODULE_PAYMENT_RAKUTEN_INFO_TEXT';
    $this->show_payment_info = 0;
  }
  function fields($theData=false, $back=false){
    global $order;
    $total_cost = $order->info['total'];
    $code_fee = $this->calc_fee($total_cost); 
    $added_hidden = tep_draw_hidden_field('code_fee', $code_fee);

    if ($back) {
    return array(
                 array(
                       "code"=>'rak_tel',
                       "title"=>TS_MODULE_PAYMENT_RAKUTEN_TELNUMBER_TEXT,
                       "field"=>tep_draw_input_field('rak_tel', $theData['rak_tel']),
                       "rule"=>array(basePayment::RULE_NOT_NULL, basePayment::RULE_CHECK_TEL),
                       )

                ); 
    } else {
    return array(
                 array(
                       "code"=>'',
                       "title"=>'',
                       "field"=>$added_hidden,
                       "rule"=>'',
                       "message"=>"",
                       ),
                 array(
                       "code"=>'rakuten_telnumber',
                       "title"=>TS_MODULE_PAYMENT_RAKUTEN_TELNUMBER_TEXT,
                       "field"=>tep_draw_input_field('rakuten_telnumber', $theData['rakuten_telnumber'],'onpaste="return false"').TS_MODULE_PAYMENT_RAKUTEN_MUST_INPUT,
                       "rule"=>array(basePayment::RULE_NOT_NULL, basePayment::RULE_CHECK_TEL),
                       "error_msg" => array(TS_MODULE_PAYMENT_RAKUTEN_BANK_TEXT_ERROR_MESSAGE,TS_MODULE_PAYMENT_RAKUTEN_BANK_TEXT_ERROR_MESSAGE) 
                       ),
                 array(
                       "code"=>'rakuten_telnumber_again',
                       "title"=>TS_MODULE_PAYMENT_RAKUTEN_TELNUMBER_CONFIRMATION_TEXT,
                       "field"=>tep_draw_input_field('rakuten_telnumber_again', $theData['rakuten_telnumber_again'],'onpaste="return false"').TS_MODULE_PAYMENT_RAKUTEN_MUST_INPUT,
                       "rule"=>array(basePayment::RULE_NOT_NULL,
                         basePayment::RULE_CHECK_TEL, basePayment::RULE_SAME_TO),
                       "params_code"=>'rakuten_telnumber',
                       "error_msg" => array(TS_MODULE_PAYMENT_RAKUTEN_BANK_TEXT_ERROR_MESSAGE, TS_MODULE_PAYMENT_RAKUTEN_BANK_TEXT_ERROR_MESSAGE, TS_MODULE_PAYMENT_RAKUTEN_BANK_TEXT_ERROR_MESSAGE_NOE) 
                       ),
                 );
    }
  }

  // class constructor

  // class methods
  function update_status() {
    global $order;
    if ( ($this->enabled == true) && ((int)MODULE_PAYMENT_RAKUTEN_BANK_ZONE > 0) ) {
      $check_flag = false;
      $check_query = tep_db_query("select zone_id from " . TABLE_ZONES_TO_GEO_ZONES . " where geo_zone_id = '" . MODULE_PAYMENT_RAKUTEN_BANK_ZONE . "' and zone_country_id = '" . $order->billing['country']['id'] . "' order by zone_id");
      while ($check = tep_db_fetch_array($check_query)) {
        if ($check['zone_id'] < 1) {
          $check_flag = true;
          break;
        } elseif ($check['zone_id'] == $order->billing['zone_id']) {
          $check_flag = true;
          break;
        }
      }

      if ($check_flag == false) {
        $this->enabled = false;
      }
    }
  }

  // class methods
  function javascript_validation() {
    return false;
  }

  function selection($theData) {
    global $currencies;
    global $order;

    $total_cost = $order->info['total'];      // 税金も含めた代金の総額
    $f_result = $this->calc_fee($total_cost); // 手数料

    $added_hidden = ''; // added by rekam
    if (!empty($this->n_fee)) {
      $s_message = $f_result ? (MODULE_PAYMENT_RAKUTEN_BANK_TEXT_FEE . '&nbsp;' . $currencies->format($this->n_fee)) : ('<font color="#FF0000">' . $this->s_error . '</font>');
    } else {
      $s_message = $f_result ? '': ('<font color="#FF0000">' . $this->s_error . '</font>');
    }

    $email_default_str = ''; 

      $selection = array(
          'id' => $this->code,
          'module' => $this->title,
          'fields' => array(
                            array('title' => MODULE_PAYMENT_RAKUTEN_BANK_TEXT_PROCESS.'xv',
                                  'field' => ''),
                            array('title' => $s_message,
                                  'field' => $added_hidden)
                            )
                         );
      
    return $selection;
  }

  function pre_confirmation_check() {
    return true;
    global $_POST;

    if ($_POST['rakuten_telnumber'] == "" || $_POST['rakuten_telnumber_again'] == "") {
      $payment_error_return = 'payment_error=' . $this->code ;
      tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT, $payment_error_return, 'SSL', true, false));

    } else if
      (!preg_match("/^(\+\d{2}){0,1}((\d{2}(-){0,1}\d{4})|(\d{3}(-){0,1}\d{3})|(\d{3}(-){0,1}\d{4}))(-){0,1}\d{4}$/", strtr($_POST['rakuten_telnumber'], $this->arrs2d))||
       !preg_match("/^(\+\d{2}){0,1}((\d{2}(-){0,1}\d{4})|(\d{3}(-){0,1}\d{3})|(\d{3}(-){0,1}\d{4}))(-){0,1}\d{4}$/", strtr($_POST['rakuten_telnumber_again'], $this->arrs2d))){
        $payment_error_return = 'payment_error=' . $this->code ;
        tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT,
              $payment_error_return.'&type=nom', 'SSL', true, false));
      } else if (strtr($_POST['rakuten_telnumber'], $this->arrs2d) != strtr($_POST['rakuten_telnumber_again'], $this->arrs2d)) {
        $payment_error_return = 'payment_error=' . $this->code; 
        $redirect_url = tep_href_link(FILENAME_CHECKOUT_PAYMENT, $payment_error_return . '&type=noe', 'SSL', true, false);
        //do for &type turn into &amp;type url ,fix it afterlater
        $url_test = explode('?',$redirect_url);
        if ($url_test[1] == 'payment_error=rakuten_bank&amp;type=noe')
        {
          $url_test[1] = 'payment_error=rakuten_bank&type=noe';
          $redirect_url = $url_test[0] .'?'. $url_test[1]; 
        }
        //do for &type turn into &amp;type url ,fix it afterlater
        //tep_redirect(tep_href_link(FILENAME_CHECKOUT_PAYMENT, $payment_error_return . '&type=noe', 'SSL', true, false));
        tep_redirect($redirect_url);

      } 
  }
  
  function preorder_confirmation_check() {
    global $_POST;
    if ($_POST['rakuten_telnumber'] == "" || $_POST['rakuten_telnumber_again'] == "") {
      return 3;
    } else if
      (!preg_match("/^(\+\d{2}){0,1}((\d{2}(-){0,1}\d{4})|(\d{3}(-){0,1}\d{3})|(\d{3}(-){0,1}\d{4}))(-){0,1}\d{4}$/", strtr($_POST['rakuten_telnumber'], $this->arrs2d))||
       !preg_match("/^(\+\d{2}){0,1}((\d{2}(-){0,1}\d{4})|(\d{3}(-){0,1}\d{3})|(\d{3}(-){0,1}\d{4}))(-){0,1}\d{4}$/", strtr($_POST['rakuten_telnumber_again'], $this->arrs2d))){
        return 3; 
      } else if (strtr($_POST['rakuten_telnumber'], $this->arrs2d) != strtr($_POST['rakuten_telnumber_again'], $this->arrs2d)) {
        return 1;
      } 
  }

  function confirmation() {
    global $currencies;
    global $_POST;

    $s_result = !$_POST['codt_fee_error'];

    if (!empty($_POST['codt_fee'])) {
      //$s_message = $s_result ? (MODULE_PAYMENT_RAKUTEN_BANK_TEXT_FEE . '&nbsp;' . $currencies->format($_POST['codt_fee'])) : ('<font color="#FF0000">' . $_POST['codt_fee_error'] . '</font>');
      $s_message = $s_result ? '' : ('<font color="#FF0000">' . $_POST['codt_fee_error'] . '</font>');
    } else {
      $s_message = $s_result ? '' : ('<font color="#FF0000">' . $_POST['codt_fee_error'] . '</font>');
    }
    return array(
                 'title' => str_replace("#TELNUMBER#",$_POST['rakuten_telnumber'],nl2br(constant("TS_MODULE_PAYMENT_".strtoupper($this->code)."_TEXT_CONFIRMATION"))),
		 'fields' => array(
				   array('title' => constant("TS_MODULE_PAYMENT_".strtoupper($this->code)."_TEXT_SHOW"), 'field' => ''),  
				   array('title' => $s_message, 'field' => '')  
				   )           
		 );

  }

  function process_button() {
    global $currencies;
    global $_POST;
    global $order, $point;

    // 追加 - 2007.01.05 ----------------------------------------------
    $total = $order->info['total'];
    if ((MODULE_ORDER_TOTAL_CODT_STATUS == 'true')
        && ($payment == 'cod_table')
        && isset($_POST['codt_fee'])
        && (0 < intval($_POST['codt_fee']))) {
      $total += intval($_POST['codt_fee']);
    }

    //Add point
    if ((MODULE_ORDER_TOTAL_POINT_STATUS == 'true')
        && (0 < intval($point))) {
      $total -= intval($point);
    }   

    if(MODULE_ORDER_TOTAL_CONV_STATUS == 'true' && ($payment == 'rakuten_bank')) {
      $total += intval($_POST['codt_fee']);
    }
    // 追加 - 2007.01.05 ----------------------------------------------

    // email_footer に使用する文字列
    $s_message = $_POST['codt_fee_error']
      ? $_POST['codt_fee_error']
      : sprintf(MODULE_PAYMENT_RAKUTEN_BANK_TEXT_MAILFOOTER,
          $currencies->format($total),
          $currencies->format($_POST['codt_fee']));

    return tep_draw_hidden_field('codt_message', $s_message)
      . tep_draw_hidden_field('rakuten_telnumber', $_POST['rakuten_telnumber']) 
      . tep_draw_hidden_field('codt_fee',$_POST['codt_fee']); // for ot_codt
  }

  function before_process() {
    global $_POST;

  }

  function after_process() {
    return false;
  }

  function get_error() {
    global $_POST,$_GET;

    if (isset($_GET['payment_error']) && (strlen($_GET['payment_error']) > 0)) {
      if (isset($_GET['type']) && $_GET['type'] == 'noe')
      {
        $error_message = MODULE_PAYMENT_RAKUTEN_BANK_TEXT_ERROR_MESSAGE_NOE;
      }
      else if (isset($_GET['type']) && $_GET['type'] == 'nom')
      {
        $error_message = MODULE_PAYMENT_RAKUTEN_BANK_TEXT_ERROR_MESSAGE_NOM;
      }
      else
      {
        $error_message = MODULE_PAYMENT_RAKUTEN_BANK_TEXT_ERROR_MESSAGE;
      }

      return array('title' => $this->title.' エラー!',
          'error' => $error_message);

    }else{
      return false;
    }
  }
  
  function get_preorder_error($error_type) {
      if ($error_type == 1)
      {
        $error_message = TS_MODULE_PAYMENT_RAKUTEN_BANK_TEXT_ERROR_MESSAGE_NOE;
      }
      else if ($error_type == 2)
      {
        $error_message = TS_MODULE_PAYMENT_RAKUTEN_BANK_TEXT_ERROR_MESSAGE_NOM;
      }
      else
      {
        $error_message = TS_MODULE_PAYMENT_RAKUTEN_BANK_TEXT_ERROR_MESSAGE;
      }
    return $error_message; 
  }

  function check() {
    if (!isset($this->_check)) {
      $check_query = tep_db_query("select configuration_value from " . TABLE_CONFIGURATION . " where configuration_key = 'MODULE_PAYMENT_RAKUTEN_BANK_STATUS' and site_id = '".$this->site_id."'");
      $this->_check = tep_db_num_rows($check_query);
    }
    return $this->_check;
  }

  function install() {
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added, site_id) values ('楽天銀行を有効にする', 'MODULE_PAYMENT_RAKUTEN_BANK_STATUS', 'True', '楽天銀行による支払いを受け付けますか?', '6', '1', 'tep_cfg_select_option(array(\'True\', \'False\'), ',now(), ".$this->site_id.");");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added, site_id) values ('加盟店コード', 'MODULE_PAYMENT_RAKUTEN_BANK_IP', '', '加盟店コードの設定をします。', '6', '2', now(), ".$this->site_id.")");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added, site_id) values ('接続URL', 'MODULE_PAYMENT_RAKUTEN_BANK_URL', '', '接続URLの設定をします。', '6', '6', now(), ".$this->site_id.")");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added, site_id) values ('決済手数料', 'MODULE_PAYMENT_RAKUTEN_BANK_COST', '99999999999:*0', '決済手数料 例: 代金300円以下、30円手数料をとる場合　300:*0+30, 代金301～1000円以内、代金の2％の手数料をとる場合　999:*0.02, 代金1000円以上の場合、手数料を無料する場合　99999999:*0, 無限大の符号を使えないため、このサイトで存在可能性がない数値で使ってください。 300:*0+30では*0がなければ、手数料は300+30になってしまいますので、ご注意ください。', '6', '3', now(), ".$this->site_id.")");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added, site_id) values ('表示の整列順', 'MODULE_PAYMENT_RAKUTEN_BANK_SORT_ORDER', '0', '表示の整列順を設定できます。数字が小さいほど上位に表示されます.', '6', '0' , now(), ".$this->site_id.")");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, use_function, set_function, date_added, site_id) values ('適用地域', 'MODULE_PAYMENT_RAKUTEN_BANK_ZONE', '0', '適用地域を選択すると、選択した地域のみで利用可能となります.', '6', '4', 'tep_get_zone_class_title', 'tep_cfg_pull_down_zone_classes(', now(), ".$this->site_id.")");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, use_function, date_added, site_id) values ('初期注文ステータス', 'MODULE_PAYMENT_RAKUTEN_BANK_ORDER_STATUS_ID', '0', '設定したステータスが受注時に適用されます.', '6', '5', 'tep_cfg_pull_down_order_statuses(', 'tep_get_order_status_name', now(), ".$this->site_id.")");
    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added, site_id) values ('決済可能金額', 'MODULE_PAYMENT_RAKUTEN_BANK_MONEY_LIMIT', '0,99999999999', '決済可能金額の最大と最小値の設置
      例：0,3000
      0,3000円に入れると、0円から3000円までの金額が決済可能。設定範囲外の決済は不可。', '6', '0', now(), ".$this->site_id.")");

    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added, site_id) values ('表示設定', 'MODULE_PAYMENT_RAKUTEN_BANK_LIMIT_SHOW', 'a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}', '表示設定', '6', '1', 'tep_cfg_payment_checkbox_option(array(\'1\', \'2\'), ',now(), ".$this->site_id.");");

    tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added, site_id) values ('予約注文', 'MODULE_PAYMENT_RAKUTEN_BANK_PREORDER_SHOW', 'True', '予約注文で楽天銀行を表示します', '6', '1', 'tep_cfg_select_option(array(\'True\', \'False\'), ',now(), ".$this->site_id.");");
  }

  function remove() {
    tep_db_query("delete from " . TABLE_CONFIGURATION . " where configuration_key in ('" . implode("', '", $this->keys()) . "') and site_id = '".$this->site_id."'");
  }

  function keys() {
    /*
       'MODULE_PAYMENT_RAKUTEN_BANK_IP', 
       'MODULE_PAYMENT_RAKUTEN_BANK_URL', 
     */
    return array( 
        'MODULE_PAYMENT_RAKUTEN_BANK_STATUS', 
        'MODULE_PAYMENT_RAKUTEN_BANK_LIMIT_SHOW', 
        'MODULE_PAYMENT_RAKUTEN_BANK_PREORDER_SHOW', 
        'MODULE_PAYMENT_RAKUTEN_BANK_ZONE', 
        'MODULE_PAYMENT_RAKUTEN_BANK_ORDER_STATUS_ID' , 
        'MODULE_PAYMENT_RAKUTEN_BANK_SORT_ORDER', 
        'MODULE_PAYMENT_RAKUTEN_BANK_COST', 
        'MODULE_PAYMENT_RAKUTEN_BANK_MONEY_LIMIT',
        'MODULE_PAYMENT_RAKUTEN_BANK_MAILSTRING',
        'MODULE_PAYMENT_RAKUTEN_BANK_PRINT_MAILSTRING',
);
  }
  function replace_for_telnumber($str){
    return str_replace('-','',strtr($str,$this->arrs2d));
  }
  function dealComment($comment, $session_paymentinfo_name)
  {
    if($_POST['rakuten_telnumber']){
      $pay_comments = '電話番号:'.$this->replace_for_telnumber($_POST['rakuten_telnumber']); 
    }else if($_POST['rak_tel']){
      $pay_comments = '電話番号:'.$this->replace_for_telnumber($_POST['rak_tel']); 
    }else{
      $pay_comments = '電話番号:';
    }
    $comment = $pay_comments ."\n".$comment;
    $payment_bank_info['add_info'] = $pay_comments;
    $res_arr = array('comment'=> $comment,
          'payment_bank_info' => $payment_bank_info);
    return $res_arr;
  }
  
  function deal_preorder_additional($pInfo, &$sql_data_array)
  {
    $pay_comments = '電話番号:'.$this->replace_for_telnumber($pInfo['rakuten_telnumber']); 
    $sql_data_array['raku_text'] = $pay_comments; 
    
    $comment = $pay_comments ."\n".$pInfo['yourmessage'];
    return $comment;
  }
  function checkPreorderRakuEmail($email)
  {
    if (!empty($email)) {
      return true; 
    }
    return false; 
  }

function getMailString($option=''){
    $email_printing_order .= 'この注文は【販売】です。' . "\n";
    $email_printing_order .=
      '------------------------------------------------------------------------'
      . "\n";
    $email_printing_order .= '備考の有無　　　　　：□ 無　　｜　　□ 有　→　□
      返答済' . "\n";
    $email_printing_order .=
      '------------------------------------------------------------------------'
      . "\n";
    $email_printing_order .= '在庫確認　　　　　　：□ 有　　｜　　□
      無　→　入金確認後仕入' . "\n";
    $email_printing_order .=
      '------------------------------------------------------------------------'
      . "\n";
    $email_printing_order .=
      '入金確認　　　　　●：＿＿月＿＿日　→　金額は' .
      abs($option) . '円ですか？　□ はい' . "\n";
    $email_printing_order .=
      '------------------------------------------------------------------------'
      . "\n";
    $email_printing_order .= '入金確認メール送信　：□ 済' . "\n";
    $email_printing_order .=
      '------------------------------------------------------------------------'
      . "\n";
    $email_printing_order .=
      '発送　　　　　　　　：＿＿月＿＿日' . "\n";
    $email_printing_order .=
      '------------------------------------------------------------------------'
      . "\n";
    $email_printing_order .= '残量入力→誤差有無　：□
      無　　｜　　□ 有　→　報告　□' . "\n";
    $email_printing_order .=
      '------------------------------------------------------------------------'
      . "\n";
    $email_printing_order .= '発送完了メール送信　：□
      済' . "\n";    
    $email_printing_order .=
    '------------------------------------------------------------------------' . "\n";
    $email_printing_order .= '最終確認　　　　　　：確認者名＿＿＿＿' . "\n";
    $email_printing_order .= '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━' . "\n";
    return $email_printing_order;
  }
   function adminSelection()
   {
     return array(
                  'code'=>$this->code,
                  'fields'=>
                  array(
                        array(
                              "title"=>'電話番号：',
                              "field"=>'<input type="text" name="rak_tel" />',
                              "message"=>$_SESSION['checkform']['rak_tel']?$_SESSION['checkform']['rak_tel']:'',
                              )
                        )
                  );
     
  }

   /*
     检查提交是否符合规则，如果不复合需要在SESSION里放上错误信息并返回false，如果符合 则返回true
    */
   function checkAdminSelection(){
     if(isset($_POST['rak_tel']) and !empty($_POST['rak_tel'])){
       return true;
     }else {
       $_SESSION['checkform']['rak_tel']='something go wrong';
       return false;
     }

   }
    
  function admin_add_additional_info(&$sql_data_array)
  {
      global $_POST; 
      $sql_data_array['raku_text'] = '電話番号:'.$_POST['rak_tel']; 
  }
  
  function admin_deal_comment($order_info)
  {
    return $order_info['raku_text']; 
  }
}
?>
