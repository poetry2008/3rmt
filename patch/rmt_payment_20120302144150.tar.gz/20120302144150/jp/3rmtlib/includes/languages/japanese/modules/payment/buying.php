<?php
/*
  $Id: fc0d05e6f5a0d7164e257ccfbc482b6c5915e098 $
*/
define('TS_MODULE_PAYMENT_BUYING_TEXT_TITLE', '銀行振込(買い取り)');
define('TS_MODULE_PAYMENT_BUYING_TEXT_EXPLAIN', '');
define('TS_MODULE_PAYMENT_BUYING_TEXT_DESCRIPTION', '');
define('TS_MODULE_PAYMENT_BUYING_TEXT_EMAIL_FOOTER', '');
define('TS_MODULE_PAYMENT_BUYING_TEXT_PROCESS', '銀行振込(買い取り)決済手数料が別途かかります。');
define('TS_MODULE_PAYMENT_BUYING_TEXT_FEE', '銀行振込(買い取り)手数料:');
define('TS_MODULE_PAYMENT_BUYING_TEXT_MAILFOOTER', '');
define('TS_MODULE_PAYMENT_BUYING_TEXT_ERROR_MESSAGE', '銀行振込(買い取り)決済の処理中にエラーが発生しました. 入力内容を訂正しもう一度試してください。　');
define('TS_MODULE_PAYMENT_BUYING_TEXT_SHOW', '');
define('TS_MODULE_PAYMENT_BUYING_TEXT_OVERFLOW_ERROR', 'お買い上げ金額が銀行振込(買い取り)の制限を超えたためお取り扱いできません。');
define('TS_MODULE_PAYMENT_BUYING_TEXT_CONFIRMATION',"");
define('TS_CONFIRMATION_BUYING_TEXT_TITLE', '銀行振込(買い取り)');
define('TS_CONFIRMATION_BUYING_TEXT_FEE', '銀行振込(買い取り)手数料:');
define('TS_TEXT_HANDLE_FEE_CONFIRMATION', '手数料:');
define('TS_TEXT_POINT_NOW_TWO','<b>買取はポイントがつきません</b>&nbsp;&nbsp;今回の獲得予定ポイント:');
define('TS_TEXT_BANK_ERROR_NAME', '【金融機関名】が入力されていません');
define('TS_TEXT_BANK_ERROR_KAMOKU', '【口座種別】が入力されていません');
define('TS_TEXT_BANK_ERROR_SHITEN', '【支店名】が入力されていません');
define('TS_TEXT_BANK_ERROR_KOUZA_NUM', '【口座番号】が入力されていません');
define('TS_TEXT_BANK_ERROR_KOUZA_NUM2', '【口座番号】は半角で入力してください。');
define('TS_TEXT_BANK_ERROR_KOUZA_NAME', '【口座名義】が入力されていません');
define('TS_TABLE_HEADING_BANK', '振込先口座情報');
define('TS_TEXT_BANK_NAME', '金融機関名:');
define('TS_TEXT_BANK_SHITEN', '支店名:');
define('TS_TEXT_BANK_KAMOKU', '口座種別:');
define('TS_TEXT_BANK_KOUZA_NUM', '口座番号:');
define('TS_TEXT_BANK_KOUZA_NAME', '口座名義:');
define('TS_TEXT_BANK_SELECT_KAMOKU_F', '普通');
define('TS_TEXT_BANK_SELECT_KAMOKU_T', '当座');
define('TS_TEXT_BANK_KOUZA_NAME_READ', '<font color="#ff0000">カタカナ</font>で入力してください');

define('TS_TEXT_ERROR','エラー!');

?>
