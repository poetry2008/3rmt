<?php
/*
  $Id: 006c8d888b523edb355b1aed33db33f07e061e08 $
*/

  define('TS_MODULE_PAYMENT_FREE_PAYMENT_TEXT_TITLE', '支払いなし');
  define('TS_MODULE_PAYMENT_FREE_PAYMENT_TEXT_EXPLAIN', '総額が0円なので支払いは発生しません。');
  define('TS_MODULE_PAYMENT_FREE_PAYMENT_TEXT_DESCRIPTION', '総額が0円なので支払いは発生しません。');
  define('TS_MODULE_PAYMENT_FREE_PAYMENT_TEXT_EMAIL_FOOTER', '');
  define('TS_MODULE_PAYMENT_FREE_PAYMENT_TEXT_PROCESS', '支払いなし決済手数料が別途かかります。');
  define('TS_MODULE_PAYMENT_FREE_PAYMENT_TEXT_FEE', '支払いなし手数料:');
  define('TS_MODULE_PAYMENT_FREE_PAYMENT_TEXT_MAILFOOTER', '');
  define('TS_MODULE_PAYMENT_FREE_PAYMENT_TEXT_OVERFLOW_ERROR','お買い上げ金額が支払いなしの制限を超えたためお取り扱いできません。');
  define('TS_MODULE_PAYMENT_FREE_PAYMENT_TEXT_ERROR_MESSAGE', '支払いなし決済の処理中にエラーが発生しました. 入力内容を訂正しもう一度試してください。　');
  define('TS_MODULE_PAYMENT_FREE_PAYMENT_TEXT_SHOW', '');
//  define('TS_MODULE_PAYMENT_FREE_PAYMENT_TEXT_SHOW', '振込先口座情報に誤りがないかご確認ください。');
  define('TS_MODULE_PAYMENT_FREE_PAYMENT_TEXT_CONFIRMATION', '総額が0円なので支払いは発生しません。');
