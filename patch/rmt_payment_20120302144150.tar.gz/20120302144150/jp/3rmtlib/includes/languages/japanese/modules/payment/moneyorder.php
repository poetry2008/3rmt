<?php
/*
  $Id: 4fd9a2cbc5f3a79b540f09444e2ffb02f4d25301 $
*/

  define('TS_MODULE_PAYMENT_MONEYORDER_TEXT_TITLE', '銀行振込');// '代金先払い'/'郵便振替'/'現金書留'に変更して使用できます
  define('TS_MODULE_PAYMENT_MONEYORDER_TEXT_EXPLAIN', 'ジャパンネット銀行またはセブン銀行へお振り込み。<br>振込手数料はお客様のご負担となります。');
  define('TS_MODULE_PAYMENT_MONEYORDER_TEXT_DESCRIPTION', 'ジャパンネット銀行またはセブン銀行へお振り込み。<br>振込手数料はお客様のご負担となります。'); 
  define('TS_MODULE_PAYMENT_MONEYORDER_TEXT_EMAIL_FOOTER','ジャパンネット銀行またはセブン銀行へお振り込み。<br>振込手数料はお客様のご負担となります。'. EMAIL_SIGNATURE);  //Add Japanese osCommerce
  
  define('TS_MODULE_PAYMENT_MONEYORDER_TEXT_FEE', '銀行振込手数料:');
  define('TS_MODULE_PAYMENT_MONEY_ORDER_TEXT_PROCESS', '銀行振込決済手数料が別途かかります。');
  define('TS_MODULE_PAYMENT_MONEYORDER_TEXT_OVERFLOW_ERROR', 'お買い上げ金額が銀行振込の制限を超えたためお取り扱いできません。');
  define('TS_MODULE_PAYMENT_MONEY_ORDER_TEXT_MAILFOOTER', '');
  define('TS_MODULE_PAYMENT_MONEY_ORDER_TEXT_ERROR_MESSAGE', '銀行振込決済の処理中にエラーが発生しました. 入力内容を訂正しもう一度試してください。　');
  define('TS_MODULE_PAYMENT_MONEYORDER_TEXT_CONFIRMATION',"下記いずれかの口座へお振り込みください。
------------------------------------------
銀行名　　：　ジャパンネット銀行 
支店名　　：　本店営業部
口座種別　：　普通
口座名義　：　カ）アイアイエムワイ
口座番号　：　1164394
------------------------------------------
銀行名　　：　セブン銀行
支店名　　：　アイリス支店
口座種別　：　普通
口座名義　：　イイマ　ユキオ
口座番号　：　0560153
------------------------------------------
※ 必ずご注文時に入力したお名前でお振り込みください。
※ 振込手数料はお客様のご負担となります。
※ 取引日時までにお支払いができない場合は、必ずご連絡ください。
　 ご連絡がない場合、在庫引き当てを解除することがあります。
※ お振り込みはご注文から7日以内にお願いいたします。
※ ご入金を株式会社iimyが確認した時点でご契約の成立となります。
");
