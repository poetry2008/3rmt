<?php
define('BASEPAYMENT_ERROR_MSG', '入力内容を確認し、再度入力してください。');
define('BASEPAYMENT_ERROR_NUMBER_MSG', '半角で入力してください');
