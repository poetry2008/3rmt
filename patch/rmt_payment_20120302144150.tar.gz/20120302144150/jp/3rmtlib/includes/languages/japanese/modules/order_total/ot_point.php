<?php
/*
  $Id: 3ddc152cd6f4a3b499c02c875269c151b99b4b68 $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_POINT_TITLE', '割引');
  define('MODULE_ORDER_TOTAL_POINT_DESCRIPTION', 'ポイント割引額');
?>
