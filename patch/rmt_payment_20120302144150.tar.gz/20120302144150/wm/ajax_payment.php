<?php

require('includes/application_top.php');
require(DIR_WS_ACTIONS.'ajax_payment.php');
