<?php
/*
  $Id: 53e8d004a99b0e91204a02d4083b9c0abfae6d96 $
*/
define('NAVBAR_CHANGE_PREORDER_TITLE', '最終確認');
define('PRORDER_CONFIRM_PRODUCT_INFO', '数量 / 商品名');
define('PRODUCT_UNIT_TEXT', '個');
define('MONEY_UNIT_TEXT', '円');
define('PRORDER_CONFIRM_FETCH_INFO', '取引時間:');
define('PREORDER_CONFIRM_FETCH_TIME_READ', 'オプション:');
define('PREORDER_CONFIRM_FETCH_TIME_DAY', '取引希望日:');
define('PREORDER_CONFIRM_FETCH_TIME_DATE', '取引希望時間:');
define('PREORDER_CONFIRM_CHARACTER', 'お客様のキャラクター名：');
define('CHANGE_ORDER_CONFIRM_PAYMENT', 'お支払い方法');
define('CHANGE_PREORDER_HANDLE_FEE_TEXT', '手数料:');
define('CHANGE_PREORDER_POINT_TEXT', '今回の獲得予定ポイント:');
define('CHANGE_PREORDER_CONFIRM_BUTTON_INFO', '<b>ご注文内容をご確認の上「注文する」をクリックしてください。</b>');
define('CHANGE_PREORDER_BREADCRUMB_FETCH', '注文');
define('CHANGE_PREORDER_POINT_TEXT_BUY','<b>買取はポイントがつきません</b>&nbsp;&nbsp;今回の獲得予定ポイント:');
