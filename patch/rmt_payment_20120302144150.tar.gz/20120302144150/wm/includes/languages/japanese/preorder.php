<?php
/*
  $Id: f0e95dc4735a5893ce56456e4962a13348b94521 $
*/

define('NAVBAR_TITLE', '商品を予約する');
define('HEADING_TITLE', '%sを予約する');
define('HEADING_TITLE_ERROR', '商品を予約する');
define('ERROR_INVALID_PRODUCT', '商品が見つかりません...');
define('FORM_TITLE_CUSTOMER_DETAILS', 'お客様について');
define('FORM_TITLE_FRIEND_DETAILS', '予約商品について');
define('FORM_TITLE_FRIEND_MESSAGE', 'ご要望');
define('FORM_FIELD_CUSTOMER_EMAIL', 'メールアドレス:');
define('FORM_FIELD_FRIEND_NAME', 'ご希望個数:');
define('FORM_FIELD_PREORDER_FIXDAY', '有効期限:');
define('FORM_FIELD_PREORDER_PAYMENT', 'お支払い方法');
define('FORM_FIELD_CUSTOMER_LASTNAME', '姓:');
define('FORM_FIELD_CUSTOMER_FIRSTNAME', '名:');
?>
