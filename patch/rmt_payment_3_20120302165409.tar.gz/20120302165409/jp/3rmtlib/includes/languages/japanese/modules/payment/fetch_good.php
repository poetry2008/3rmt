<?php
/*
  $Id: 8148f25c0a7d151412fb6eb4934162838343aefc $
*/

  define('TS_MODULE_PAYMENT_FETCH_GOOD_TEXT_TITLE', '来店支払い');
  define('TS_MODULE_PAYMENT_FETCH_GOOD_TEXT_EXPLAIN', 'ご来店による現金支払です。');
  define('TS_MODULE_PAYMENT_FETCH_GOOD_TEXT_DESCRIPTION', 'ご来店による現金支払です。');
  define('TS_MODULE_PAYMENT_FETCH_GOOD_TEXT_EMAIL_FOOTER', '');
  define('TS_MODULE_PAYMENT_FETCH_GOOD_TEXT_PROCESS', '来店支払い決済手数料が別途かかります。');
  define('TS_MODULE_PAYMENT_FETCH_GOOD_TEXT_FEE', '来店支払い手数料:');
  define('TS_MODULE_PAYMENT_FETCH_GOOD_TEXT_MAILFOOTER', '');
  define('TS_MODULE_PAYMENT_FETCH_GOOD_TEXT_OVERFLOW_ERROR','お買い上げ金額が来店支払いの制限を超えたためお取り扱いできません。');
  define('TS_MODULE_PAYMENT_FETCH_GOOD_TEXT_ERROR_MESSAGE', '来店支払い決済の処理中にエラーが発生しました. 入力内容を訂正しもう一度試してください。　');
  define('TS_MODULE_PAYMENT_FETCH_GOOD_TEXT_SHOW', '');
// define('TS_MODULE_PAYMENT_FETCH_GOOD_TEXT_SHOW', '振込先口座情報に誤りがないかご確認ください。');
  define('TS_MODULE_PAYMENT_FETCH_GOOD_TEXT_CONFIRMATION',"");
  define('TS_MODULE_PAYMENT_FETCH_GOOD_ADDITIONAL_TEXT_TITLE', '来店による支払い');

