<?php
/*
  $Id: 3573eb288ab7a446c9f80d87515dfe39d8967f74 $
*/

  define('TS_MODULE_PAYMENT_BUYINGPOINT_TEXT_TITLE', 'ポイント(買い取り)');
  define('TS_MODULE_PAYMENT_BUYINGPOINT_TEXT_EXPLAIN', '買取代金は当サイト でご利用できるポイントとしてお支払いされます。');
  define('TS_MODULE_PAYMENT_BUYINGPOINT_TEXT_DESCRIPTION', '買取代金は当サイト でご利用できるポイントとしてお支払いされます。');
  define('TS_MODULE_PAYMENT_BUYINGPOINT_TEXT_EMAIL_FOOTER', '');
  define('TS_MODULE_PAYMENT_BUYINGPOINT_TEXT_PROCESS', 'ポイント(買い取り)決済手数料が別途かかります。');
  define('TS_MODULE_PAYMENT_BUYINGPOINT_TEXT_FEE', 'ポイント(買い取り)手数料:');
  define('TS_MODULE_PAYMENT_BUYINGPOINT_TEXT_MAILFOOTER', '');
  define('TS_MODULE_PAYMENT_BUYINGPOINT_TEXT_OVERFLOW_ERROR','お買い上げ金額がポイント(買い取り)の制限を超えたためお取り扱いできません。');
  define('TS_MODULE_PAYMENT_BUYINGPOINT_TEXT_ERROR_MESSAGE', 'ポイント(買い取り)決済の処理中にエラーが発生しました. 入力内容を訂正しもう一度試してください。　');
  define('TS_MODULE_PAYMENT_BUYINGPOINT_TEXT_SHOW', '');
  define('TS_MODULE_PAYMENT_BUYINGPOINT_TEXT_CONFIRMATION',"買取代金は当サイト でご利用できるポイントとしてお支払いされます。");
  define('TS_MODULE_PAYMENT_BUYINGPOINT_ADDITIONAL_TEXT_TITLE', 'ポイントの加算');
