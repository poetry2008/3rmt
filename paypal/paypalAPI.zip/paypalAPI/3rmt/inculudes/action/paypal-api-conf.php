<?php
define("my_api_username","testanaka99_api1.gmail.com");
define("my_api_password","THW5VLVMGN6EBN2Q");
define("my_api_signature","AFcWxV21C7fd0v3bYYYRCpSSRl31A-xnmo0jnYaLEu6YtiFKRwhz.27E");

?>